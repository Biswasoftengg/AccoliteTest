﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.Eventing.Reader;
using System.Net;
using TestApi.Models;
using TestApi.Repository;

namespace TestApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankingController : ControllerBase
    {
        IBankRepository _bankRepo;
        public  List<UserModel> objUserModel;
        public  List<AccountModel> objAcModel;
        public BankingController(IBankRepository bankRepo) {
            _bankRepo = bankRepo;
        }

        [HttpPost]
        [Route("CreateUser")]            
        public async Task<IActionResult> CreateUser(string name, string email, string address, string userId)
        {
            try
            {
                objUserModel = _bankRepo.CreateUser(name, email, address, userId);
                return Ok(objUserModel);
            }
            catch (Exception)
            {

                return StatusCode(500, "Exception occured");
            }

        }
        [HttpPost]
        [Route("CreateAccount")]
        public async Task<IActionResult> CreateAccount(string acNumber, string accountName, string openingDate, double amount, string userId)
        {
            try
            {
                objAcModel = _bankRepo.CreateAccount(acNumber, accountName, openingDate, amount, userId);
                return Ok(objAcModel);
            }
            catch (Exception)
            {

                return StatusCode(500, "Exception occured");
            }

        }
        [HttpPost]
        [Route("DeleteAccount")]
        public async Task<IActionResult> DeleteAccount(string acNumber)
        {
            try
            {
                string msg = string.Empty;
                msg=_bankRepo.DeleteAccount(acNumber);
                return Ok(msg);
            }
            catch (Exception)
            {

                return StatusCode(500, "Exception occured");
            }

        }
        [HttpPost]
        [Route("DepositAmount")]
        public async Task<IActionResult> Deposit(string acNumber, double amount)
        {
            try
            {
                string msg = string.Empty;
                if (amount > 10000)
                {
                    msg=("Deposit can not be more than $10000");
                }
                else
                {
                    msg = _bankRepo.Deposit(acNumber, amount);
                    
                }
                return Ok(msg);

            }             
            catch (Exception)
            {

                return StatusCode(500,"Exception occured");
            }

        }
        [HttpPost]
        [Route("WithDrawAmount")]
        public async Task<IActionResult> WithDraw(string acNumber, double amount)
        {
            try
            {                               
                 string message=_bankRepo.WithDraw(acNumber, amount);                
                return Ok(message);

            }
            catch (Exception ex)
            {

                return StatusCode(500,"No Object Found");
            }          

        }
    }
}
