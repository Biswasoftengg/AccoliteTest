﻿namespace TestApi.Models
{
    public class AccountModel
    {
        public string AcNumber { get; set; }
        public string AccountName { get; set; }
        public string OpeningDate { get; set; }
        public double Amount { get; set; }
        public string UserId { get; set; }
    }
}
