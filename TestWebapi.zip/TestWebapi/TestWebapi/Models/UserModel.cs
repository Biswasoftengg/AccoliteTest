﻿namespace TestApi.Models
{
    public class UserModel
    {
        public string Name { get; set; }    
        public string Email { get; set; }   
        public string Address { get; set; }
        public string userId { get; set; }
        
    }
}
