﻿using System.Collections.Generic;
using System.Net;
using System.Security.Principal;
using System.Xml.Linq;
using TestApi.Models;

namespace TestApi.Repository
{
    public class BankRepository : IBankRepository
    {
        public  List<UserModel> _objUserModel;
        public  List<AccountModel> _objlistOfAcs;
        public BankRepository(List<UserModel> objUserModel, List<AccountModel> listOfAcs)
        {

            _objUserModel = objUserModel;
            _objlistOfAcs = listOfAcs;
        }
        public List<UserModel> CreateUser(string name, string email ,string address,string userId)
        {
            if (_objUserModel == null)
                return new List<UserModel>() { new UserModel() { Name = name, Email = email, Address = address, userId = userId } };
            else
                _objUserModel.Add(new UserModel() { Name = name, Email = email, Address = address, userId = userId });

            return _objUserModel;

        }
        public List<AccountModel> CreateAccount(string acNumber , string accountName ,string openingDate,double amount,string userId)
        {
            if (_objlistOfAcs == null)
                return new List<AccountModel>() { new AccountModel() { AcNumber = acNumber, AccountName = accountName, OpeningDate = openingDate, Amount = amount, UserId = userId } };
            else
                _objlistOfAcs.Add(new AccountModel() { AcNumber = acNumber, AccountName = accountName, OpeningDate = openingDate, Amount = amount, UserId = userId });
            return _objlistOfAcs;
        }
        public string  DeleteAccount(string acNumber)
        {
            //var acModel = _objlistOfAcs.Find(y => y.AcNumber == acNumber);
            string msg = string.Empty;
            var itemToRemove = _objlistOfAcs.SingleOrDefault(r => r.AcNumber == acNumber);
            if (itemToRemove != null)
            {
                _objlistOfAcs.Remove(itemToRemove);
                msg = "Account Number " + acNumber + " Deleted";
            }
            else
            {
                msg = "Account " + acNumber +" Does not exist";
            }

            return msg;
        }

        public string Deposit(string acNumber,double amount)
        {
            string msg = string.Empty;
            var acModel = _objlistOfAcs.Find(y => y.AcNumber == acNumber);
            if (acModel != null)
            {
                acModel.Amount += amount;
                msg = "Deposited to Account Number " + acNumber;
            }
            else
            {
                msg = "Account " + acNumber + " Does not exist";
            }
            return msg;
        }

        public string WithDraw(string acNumber, double amount)
        {
            string msg=string.Empty;
            var acToWithdraw = _objlistOfAcs.SingleOrDefault(r => r.AcNumber == acNumber);
            if (acToWithdraw != null)
            {
                if ((acToWithdraw?.Amount - amount) < 100)
                {
                    msg="Account cannot have less than $100 at any time in an account";
                }
                if (amount > ((acToWithdraw.Amount) * 0.9))
                {
                    msg="Cannot withdraw more than 90% of their total balance from account in a single transaction";
                }
                else
                {
                    acToWithdraw.Amount -= amount;
                    msg= "Amount withdrawed from account "+acNumber;
                }              

            }
            else
            {
                msg = "A/c doesn't exist !";
            }
            return msg;
           
        }
    }
}
