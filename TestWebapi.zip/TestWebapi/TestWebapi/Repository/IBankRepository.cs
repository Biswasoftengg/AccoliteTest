﻿using TestApi.Models;

namespace TestApi.Repository
{
    public interface IBankRepository
    {
        List<UserModel> CreateUser(string name, string email, string address, string userId);
         List<AccountModel> CreateAccount(string acNumber, string accountName, string openingDate, double amount, string userId);
         string DeleteAccount(string acNumber);
        string Deposit(string acNumber, double amount);
         string WithDraw(string acNumber, double amount);

    }
}
