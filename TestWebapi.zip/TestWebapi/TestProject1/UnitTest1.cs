using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Net;
using System.Xml.Linq;
using TestApi.Controllers;
using TestApi.Models;
using TestApi.Repository;

namespace TestProject1
{
    [TestFixture]
    public class Tests
    {
        [OneTimeSetUp]
        public void Init()
        {
            var services = new ServiceCollection();
            services.AddSingleton(new List<UserModel>());
            services.AddSingleton(new List<AccountModel>());
            services.AddSingleton<IBankRepository>(new BankRepository(new List<UserModel>(), new List<AccountModel>()));
        }

        [Test,Order(1)]
        public void TestCreateUser()
        {
            var mock = new Mock<IBankRepository>();
            List<UserModel> lstUserModel = new List<UserModel>() { new UserModel() { Name = "Acolite", Email = "Acc@accolite.com", Address = "Hyderabad", userId = "aco" } };
            mock.Setup(p => p.CreateUser(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(lstUserModel);
            BankingController bankController = new BankingController(mock.Object);
            OkObjectResult createUserResult = bankController.CreateUser("Acolite", "Acc@accolite.com", "Hyderabad", "aco").Result as OkObjectResult;
            Assert.AreEqual(200, createUserResult.StatusCode);

        }
        [Test, Order(2)]
        public void TestCreateAccount()
        {
            var mock = new Mock<IBankRepository>();
            List<AccountModel> lstAccountModel = new List<AccountModel>() { new AccountModel() { AcNumber = "Ac01", AccountName = "AccoliteAcc", OpeningDate = "09/23/2023", Amount = 10000, UserId = "aco" } };
            mock.Setup(p => p.CreateAccount(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<double>(), It.IsAny<string>())).Returns(lstAccountModel);
            BankingController bankController = new BankingController(mock.Object);
            OkObjectResult createUserResult = bankController.CreateAccount("Ac01", "AccoliteAcc", "09/23/2023", 10000, "aco").Result as  OkObjectResult;           
            Assert.AreEqual(200, createUserResult.StatusCode);

        }
        [Test, Order(3)]
        public void TestDeposit()
        {
            var mock = new Mock<IBankRepository>();
            string message = "Deposited to Account Number Ac01";
            List<AccountModel> lstAccountModel = new List<AccountModel>() { new AccountModel() { AcNumber = "Ac01", AccountName = "AccoliteAcc", OpeningDate = "09/23/2023", Amount = 20000, UserId = "aco" } };
            mock.Setup(p => p.Deposit(It.IsAny<string>(), It.IsAny<double>())).Returns(message);
            BankingController bankController = new BankingController(mock.Object);// (mock.Object);
            OkObjectResult depositResult = bankController.Deposit("Ac01", 8000).Result as OkObjectResult;
            Assert.AreEqual(200, depositResult.StatusCode);

        }
        [Test, Order(4)]
        public void TestDepositExceedlimitAmount()
        {
            var mock = new Mock<IBankRepository>();
            string message = "Deposit can not be more than $10000";
            //List<AccountModel> lstAccountModel = new List<AccountModel>() { new AccountModel() { AcNumber = "Ac01", AccountName = "AccoliteAcc", OpeningDate = "09/23/2023", Amount = 18000, UserId = "aco" } };
            mock.Setup(p => p.Deposit(It.IsAny<string>(), It.IsAny<double>())).Returns(message);
            BankingController bankController = new BankingController(mock.Object);//(mock.Object);
            OkObjectResult createUserResult = bankController.Deposit("Ac01",15000).Result as OkObjectResult;
            Assert.AreEqual("Deposit can not be more than $10000", createUserResult.Value);

        }
      
        [Test, Order(6)]
        public void TestWithdrawlExceedLimit()
        {
            var mock = new Mock<IBankRepository>();
            string msg = "Cannot withdraw more than 90% of their total balance from account in a single transaction";
            mock.Setup(p => p.WithDraw(It.IsAny<string>(), It.IsAny<double>())).Returns(msg);
            BankingController bankController = new BankingController(mock.Object);//(mock.Object);
            OkObjectResult depositResult = bankController.WithDraw("Ac01",1802).Result as OkObjectResult;
            Assert.AreEqual("Cannot withdraw more than 90% of their total balance from account in a single transaction", depositResult.Value);

        }
        [Test, Order(7)]
        public void TestWithdrawlMinBalanceAccountLimit()
        {
            var mock = new Mock<IBankRepository>();
            string msg = "Account cannot have less than $100 at any time in an account";
            //AccountModel lstAccountModel = new AccountModel() { AcNumber = "Ac01", AccountName = "AccoliteAcc", OpeningDate = "09/23/2023", Amount = 1900000, UserId = "aco" };
            mock.Setup(p => p.WithDraw(It.IsAny<string>(), It.IsAny<double>())).Returns(msg);
            BankingController bankController = new BankingController(mock.Object);
            OkObjectResult depositResult = bankController.WithDraw("Ac01",1900000).Result as OkObjectResult;
            Assert.AreEqual("Account cannot have less than $100 at any time in an account", depositResult.Value);

        }
        [Test, Order(5)]
        public void TestWithDraw()
        {
            var mock = new Mock<IBankRepository>();
            string msg = "Amount withdrawed from account Ac01";
            mock.Setup(p => p.WithDraw(It.IsAny<string>(), It.IsAny<double>())).Returns(msg);
            BankingController bankController = new BankingController(mock.Object);// (mock.Object);
            OkObjectResult withdrawResult = bankController.WithDraw("Ac01",80).Result as OkObjectResult;
            Assert.AreEqual("Amount withdrawed from account Ac01", withdrawResult.Value);

        }
        [Test, Order(8)]
        public void TestAccountDeletion()
        {
            var mock = new Mock<IBankRepository>();
            string msg = "Account Ac01 deleted";
            mock.Setup(p => p.DeleteAccount(It.IsAny<string>())).Returns(msg);
            BankingController bankController = new BankingController(mock.Object);
            OkObjectResult deletionResult = bankController.DeleteAccount("Ac01").Result as OkObjectResult;
            Assert.AreEqual("Account Ac01 deleted", deletionResult.Value);

        }
    
    }
}